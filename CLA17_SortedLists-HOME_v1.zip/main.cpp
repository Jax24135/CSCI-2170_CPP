#include "slist.h"
#include <iostream>
#include <fstream>
#include <cassert>
using namespace std;

int main()
{
    fstream myIn;
    int size = 0;
    BookType aBook;
    slist list1;
    
    myIn.open("books.dat");
    assert(myIn);
    
    while (size<MAX_LENGTH && getline(myIn,aBook.title)) {
        getline(myIn,aBook.author);
        
        myIn >> aBook.publicationYear;
        myIn.ignore(100,'\n');
        
        list1.Insert(aBook);
    }
    list1.Reset();
    list1.SortSel();
    list1.Reset();
    
    cout << "The list of books are:\n\n";
    
    for (int i=0;i<list1.Length();i++) {
        list1.Display();
        list1.GetNextItem();
    }
    
    return 0;
}

