#ifndef SLIST_H
#define SLIST_H

#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
using namespace std;

struct BookType {
    string title;
    string author;
    int publicationYear;
    
    bool operator <= (const BookType &rhs) { return (author <= rhs.author); }
    bool operator != (const BookType &rhs) {return (publicationYear == rhs.publicationYear); }
};

const int MAX_LENGTH = 50;
typedef BookType ItemType;

class slist {
public:
    
    // default constructor
    slist();
    
    // copy constructor
    slist(const slist &rhs);
    
    // ACCESSORS
    bool IsEmpty() const;
    bool IsFull() const;
    bool IsPresent(ItemType item);
    int  Length() const;
    void Display() const;
    
    //MUTATORS
    void Insert(ItemType &item);
    void Delete(ItemType item);
    void SortSel();
    void CompareNames(ItemType &item);
    void CompareYear(ItemType &item);
    
    
    
    // ITERATORS
    void Reset();
    ItemType GetNextItem();
    
    //destructor
    ~slist();
    
private:
    int length; // list length
    ItemType data[MAX_LENGTH]; // Array
    int currentPos;
};

#endif