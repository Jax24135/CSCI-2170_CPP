#include "slist.h"

// Default Constructor
slist::slist() {
    length = 0;
}

// Copy Constructor
slist::slist(const slist &rhs) {
    length = rhs.length;
    for (int i = 0; i<length;i++) {
        data[i] = rhs.data[i];
    }
    currentPos = rhs.currentPos;
}

// ACCESSORS
int slist::Length() const {
    return length;
}

bool slist::IsEmpty() const {
    return (length == 0);
}

bool slist::IsFull() const {
    return (length == MAX_LENGTH);
}

bool slist::IsPresent(ItemType item) {
    int index=0;
    while ((index<length) && (item != data[index])) {
        index++;
    }
    
    return (index<length);
}

void slist::Display() const {
    cout << "Title: " << data[currentPos].title << endl
         << "Author: " << data[currentPos].author << endl
         << "Publication Year: " << data[currentPos].publicationYear << endl << endl;
    
    
}


// MUTATORS
void slist::Insert(ItemType &item) {
    data[length] = item;
    length++;
}

void slist::Delete(ItemType item) {
        int index=0;
        while(index<length && item != data[index]) {
            index++;
        }
        if (index<length) {
            data[index] = data[length-1];
            length--;
        }
}

void slist::SortSel() {
    ItemType temp;
    int passCount;
    int sIndx;
    int minIndx;
    
    for (passCount=0;passCount < length-1;passCount++) {
        minIndx = passCount;
        
        for (sIndx = passCount+1;sIndx<length-1;sIndx++) {
            if (data[sIndx] <= data[minIndx])
                minIndx = sIndx;
            
        }
        
        if (minIndx != passCount) {
            temp = data[minIndx];
            data[minIndx] = data[passCount];
            data[passCount] = temp;
        }
    }
        
}


// Iterators
void slist::Reset() {
    currentPos = 0;
}

ItemType slist::GetNextItem() {
    ItemType item;
    item = data[currentPos];
    if(currentPos == length-1)
        currentPos = 0;
    else
        currentPos++;
    return item;
}

slist::~slist() {}