/*
PROGRAMMER: Jonathan Jackson
Assignment: CLA3  
Class: 2170-001
Course Instructor:  Dr. Li
Due Date: Midnight, Tuesday, 9/12/2017
Description:
This program sorts 3 integers  (provided by User)
into ascending order and displays sorted order to the User's screen.

Final variables are smallNum, middleNum, and largeNum.
*/

#include <iostream>
using namespace std;

int main()
{
	int num1;	// first integer from User
	int num2;	// second integer from User
	int num3;	// third integer from User
	
	int largeNum;	// largest integer number (post-sorting)
	int middleNum;	// middle integetr number (post-sorting)
	int smallNum;	// smallest integer number (post-sorting)
	
	// Prompt User for input
	cout << "Please enter three integer values: ";

	// User assigns integers from keyboard input
	cin >> num1 >> num2 >> num3;
	
	/* Logic sorting in this section*/
		
	// check num1 against num2 and num3 to find the largest number
	if (num1 > num2 && num1 > num3) {
		largeNum = num1; // if **largest** ...assign accordingly
		
		//compare other 2 numbers
        // if 1st test fails, use simple "else" to reverse sort
		if (num2 > num3) {
			middleNum = num2;
			smallNum = num3;
		} else {
			middleNum = num3;
			smallNum = num2;
		}
	}
	
	// check if num2 is largest number against num1 && num3
	else if (num2 > num1 && num2 > num3) {
		
        // if num2 is largest, assign accordingly
        largeNum = num2;
		
		//compare other 2 numbers
        // if 1st test fails, use simple "else" to reverse sort
		if (num1 > num3) {
			middleNum = num1;
			smallNum = num3;
		} else {
			middleNum = num3;
			smallNum = num1;
        }
	}
	// check num3 against num1 and num2 to find the largest number
	// this could be an "else", but left as "else if" to verify
	else if (num3 > num1 && num3 > num2) {
	        largeNum = num3;
		
		//compare other 2 numbers
        // if 1st test fails, use simple "else" to reverse sort
		if (num1 > num2) {
			middleNum = num1;
			smallNum = num2;
		} else {
			middleNum = num2;
			smallNum = num1;
		}
	}
    
	
    // Display sorted order list to User's screen
	cout << "The three values in ascending order are: "
		<< smallNum << ' ' << middleNum << ' ' << largeNum << endl;
	
    // Exit program cleanly
    return 0;
}