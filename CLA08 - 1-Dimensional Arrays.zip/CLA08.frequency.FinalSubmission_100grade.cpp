/* asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Tuesday, 09/26/2017
 * PROGRAM ID:  frequency.cpp / The Alphabet-Array Frequency Problem
 * AUTHOR:  Jonathan Jackson
 * INSTALLATION:  MTSU
 * REMARKS:  This program reads in a line of text, counts the frequency appearance
 * of individual characters appearing in the line of text entered,
 * and displays the counts.
 */
 
#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main()
{
	string line; // line of text to be read through by 'loc'
	
	// initialize array and set default values; can't increment from NIL value
	const int ARRAY_SIZE = 26;
	int alphaArray[ARRAY_SIZE] = {0};

	// Prompt and accept User keyboard input
	cout << "Enter text: ";
	getline(cin,line);

	/* - read through the sentence
	 * 
	 * - change current text character to a lowercase char
	 *   (used for comparing to baseline 'a' value)
	 * 
	 *  - start at location '0' (first letter in sentence),
	 *    subtract base of char 'a', and increment count of corresponding 'cell'
	 *    each iteration should be checked to keep 'loc' below the total string length 
	 *    (or an ERROR could/will occur)
	 * 
	 *  sorting help:
	 * 	so 'a'-'a' is 0 or 'a'
	 *     'b'-'a' is 1 = b
	 *     'c'-'a' is 2 = c
	 */
	for (int loc = 0; loc < line.length(); loc++) {
		line[loc] = tolower(line[loc]); // convert char to lowercase
		alphaArray[line[loc]-'a']++; // increment 'cell' of 1-26 based on location minus 'a'
	}

	/* display stored alphaArray values
	 *  - '0' should be 'a' and increment from there, 'b'=1,'c'=3,'d'=4
	 *  - print corresponding array values on other side of ';'
	 */
	for (int i=0; i<26;i++){
		cout << char('a'+i) << " : " << alphaArray[i] << endl;
	}
	
	cout << endl; // extra whitespace line for end-of-program readability
	
	return 0;
}
