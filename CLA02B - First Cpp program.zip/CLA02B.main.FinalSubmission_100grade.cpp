#include<iostream> // allows I/O streams
#include<iomanip>  // manipulate decimal places

using namespace std; // adds cin/cout names

const float EURO = 0.87;  // sets global constant Euro amount

int main()
{
	float usDollars; // native USD amount
	float convertedToEUR; // post-conversion number to EUR amount
	
	//Prompt User for USD amount
	cout << "Enter amount of US Dollar you want to convert : $ ";
	cin >> usDollars;
		
	// Sets 2-decimal place formatting
	cout << fixed << setprecision(2);

	// Restates User's input + new line
	cout << "You entered $" << usDollars << endl << endl;
	
	// Conversion Process [logic]
	convertedToEUR = usDollars*EURO;
		
	// States USD-to-EUR conversion rate and displays finished conversion
	cout << "1 dollar = " << EURO << " EUR" << endl;
	cout << usDollars << " US Dollar is equivalent to " << convertedToEUR << " EUR \n \n";
	
	return 0;
}
