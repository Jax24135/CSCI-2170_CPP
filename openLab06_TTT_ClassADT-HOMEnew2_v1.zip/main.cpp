#include <iostream>
#include <string>
#include "ttt.h"
using namespace std;

void DetermineFirstTurn(char &playerTurn);

int main()
{
    TTT game;           // builds the game board
    char playerTurn;    // store the current player's mark/turn
    int x, y;           // stores x-y gameBoard coordinates
    
    cout << "Game Starts!\n";
    game.Display();  // initial display of it
    
    // need to set 1st player's turn
    DetermineFirstTurn(playerTurn);
    
    while(!game.BoardIsFull() && game.CheckWon() == 'n') {

        do { cout << "Player " << playerTurn << " makes the next move.\n"
                  << "Enter the x,y location, 0<=x<3, 0<=y<3: ";
             cin >> x >> y;
        } while(!game.Assign(x,y,playerTurn));
        
        game.Display();
        if (playerTurn == 'X')
            playerTurn = '0';
        else
            playerTurn = 'X';
    }
    
    if (game.CheckWon() == 'X')
        cout << "Player X wins!\n";
    else if (game.CheckWon() == 'O')
        cout << "Player O wins!\n";
    else
        cout << "This is a Draw game!\n";
    return 0;
}


// User-Defined Functions
void DetermineFirstTurn(char &playerTurn) {
    int tmp = rand() % 2;
    if (tmp == 1)
        playerTurn = 'X';
    else
        playerTurn = '0';
}