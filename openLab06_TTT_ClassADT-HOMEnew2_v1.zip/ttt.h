#ifndef  TTT_H
#define  TTT_H

#include <iostream>
#include <string>
using namespace std;

const int SIZE=3;
/* Minimally, you need these operations for the TTT class
You are free to add additional methods if needed */

class TTT
{

public:

    TTT();
    // Initialize each square of the gameboard to ' '

    // mutators
    bool Assign(const int &x, const int &y, const char &playerTurn);
    
    void Display() const;
    // Display the 3 x 3 gameboard on screen
    
    bool BoardIsFull() const;
    // Check to see if there is any blank square left on the gameboard (to continue to play).
    // Returns true of false depending on whether the gameboard is full or not
    
    char CheckWon() const;
    // Check whether one player won:
    // if player 'X' wins, return 'X',
    // if player 'O' wins, return 'O',
    // if no player wins yet, return 'N'.

    ~TTT(); //destructor
    
    private:
    char gameBoard[SIZE][SIZE]; // The game board //array
    
};
#endif