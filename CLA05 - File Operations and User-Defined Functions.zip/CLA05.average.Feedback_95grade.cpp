// asgn BY Dr. Li,  CSCI 2170-001, Due: Midnight, 09/19/2017
// PROGRAM ID:  average.cpp / The Averaging Problem
// AUTHOR:  Jonathan Jackson
// INSTALLATION:  MTSU
// REMARKS:  This program reads data from an existing program
// and determines the largest, smallest, total sum, and average
// of all the numbers. It also displays them invidually as it reads through
// and the end of program shows the summary info.

#include <iostream>
#include <fstream>
#include <cassert>
#include <iomanip>
using namespace std;


// Declare User-functions
void OpenFile(ifstream &myIn);
void ComputeStatistics(ifstream &myIn, int &counter, int &numLargest, int &numSmallest, int &accumulator, float &avg);
void DisplayResults(int &counter, int &numLargest, int &numSmallest, int &accumulator, float &avg);

int main()
{
	ifstream myIn;   // contains file object
	int counter = 0; // counts how many numbers are added together
	int accumulator = 0; // the sum of all numbers
    int numLargest = 0;  // constains largest number in set
	int numSmallest = 0; // contains smallest number in set
    float avg; // contains a TRUE decimal place for summary display
	
    // Opens file
	OpenFile(myIn);
    
    // Gets stats & displays individual numbers during read-through
	ComputeStatistics(myIn, counter, numLargest, numSmallest, accumulator, avg);
    
    // Shows final results
	DisplayResults(counter, numLargest, numSmallest, accumulator, avg);
    
    //Exits program cleanly
	return 0;
}

// User Defined Functions

// This function opens a file and confirms it opens succesfully
// for the ComputeStatics() function to work with.
void OpenFile(ifstream &myIn) { 
    
    string filename; // contains file to read (local function object)
    
	//Prompt User for file to open
	cout << "Please enter the filename to read: ";
	cin >> filename;
    cout << endl;
		
	// opens filename after string conversion
	myIn.open(filename.c_str());
	
	// confirms file opens successfully
	assert(myIn); //broken?
}

// Reads through all the data file. Keeps track of the smallest and largest numbers (distance from 0),
// the number of numbers read, and the number accumulator (to find the avgerage)
void ComputeStatistics(ifstream &myIn, int &counter, int &numLargest, int &numSmallest, int &accumulator, float &avg) {
	
    int currentNum; // placeholder for current number being read (local function variable)
                    // used to compare current number to largest && smallest number
    
    cout << "The values read are:\n";
    
    // reads in current number, compares to largest/smallest number already saved
    // replaces those if applicable
	while(myIn >> currentNum) {
		if (currentNum > numLargest) {
			numLargest = currentNum;
		} else if (currentNum < numSmallest) {
			numSmallest = currentNum;
		}
		
        ++counter; // every iteration, add 1
		cout << currentNum << endl; // print current number on its own line
		accumulator += currentNum; // add current number to accumulator
	}
    
    // finding the floating average    
    float fcounter = 1.0 * counter; // setup temp float-type and multiply by 1 to get counter as a float
    avg = (accumulator/fcounter); // keep TRUE decimal info by dividing by a float
    
    myIn.close(); // numbers are stored already. close the inFile
}

// This shows the summary results from previous function
void DisplayResults(int &counter, int &numLargest, int &numSmallest, int &accumulator, float &avg) {
    cout << endl
         << "Total " << counter << " numbers.\n"
         << "The largest number is " << numLargest  // prints largest number
         << ", and the smallest number is " << numSmallest << ".\n" // prints smallest number
         << "The average of these numbers is " << fixed << showpoint << setprecision(1) << avg << ".\n"; //print average with 1 decimal place
}