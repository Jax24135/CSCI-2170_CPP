// Implementation file array-based list (“list.cpp”)

#include "list.h"
#include  <iostream>
using namespace std;

List::List ()
// Constructor
// Post: length == 0
{
      length = 0;
}

// Copy Constructor
List::List(const List &rhs) {
    length = rhs.length;
    for (int i=0; i<length;i++) {
        data[i] = rhs.data[i];
    }
    currentPos = rhs.currentPos;
}

bool  List::IsEmpty ()  const
// Post: Return value is true if length is equal
//  to zero and false otherwise
{
      return (length == 0);
}

bool  List::IsFull ()  const
// Post: Return value is true if length is equal
//  to MAX_LENGTH and false otherwise
{     
    return (length == MAX_LENGTH);
}
      
int  List::Length ()  const
// Post: Return value is length
{    
      return  length;
}

void List::Insert (/* in */  ItemType  item)  {
// Pre: length < MAX_LENGTH && item is assigned
// Post: data[length@entry] == item && 
//       length == length@entry + 1
    
    if (length < MAX_LENGTH) {
        data[length] = item;
        length++;
    }
}


void List::AddAtFront(const ItemType &item) {
    if (length >= MAX_LENGTH) {
        cerr << "The array is full.\n"; // if ARRAY is full, print ERROR message
    } else {
        int index = length;
        while (index >= 0) {
            data[index+1] = data[index]; // shift all cell values up by 1
            index--;
        }
        length++;
        data[0] = item; // add new $item to cell '0'
    }
}


bool List::IsPresent( /* in */ ItemType item) const   
// Searches the list for item, reporting  whether found
// Post: Function value is true, if item is in 
//   data[0 . . length-1] and is false otherwise
{    
    int index  =  0;
    while (index < length && item != data[index])
          index++;

    return  (index < length);
}

void  List::Delete ( /* in */  ItemType  item) 
// Pre: length > 0  &&  item is assigned
// Post: IF item is in data array at entry
//      First occurrence of item is no longer 
//   in array
//         && length == length@entry - 1
//      ELSE
//       length and data array are unchanged
{    
    int  index  =  0;
    
    while (index < length  && item != data[index])
          index++;

    // IF item found, move last element into 
    //  item’s place
    if (index < length)
    {
          data[index] = data[length - 1];
          length--;
    }
}


// Deletes all instances of an item in an array
void List::DeleteAll(ItemType &item) {
    int deletions = 0;  // keeps track of each deletion
    int index = 0;      // placeholder for moving through the array
    Reset();
    
    if (IsPresent(item)) {
    // while the end of the array hasn't been reached
        while (index < length) {
            
            //for each turn, remove all instances of $item from the END of the array
            //so the last ITEM can replace the targetITEM's early-array instances
            // i.e (targetDeletion == 20 && array is [10,20,30,40,20])
            while(data[length-1] == item) {
                length--;
                deletions++;
            }
        
            //safety replace the targetITEM for deletion with a unique number
            //from the end of the array and reduce the array length by 1.
            if (data[index] == item) {
                Delete(item);
                deletions++;
            }
        
            //move through the array
            index++;
        }
        cout << deletions << " occurences of value : " << item << " deleted.\n"
             << "After deleting, the list of values are:\n";
        
    } else {
        cout << "That item isn't in the list.\n"
             << "Printing list values.\n\n";
    }
}
    
void List::Reset()
// Post: currentPos has been initialized.
{
    currentPos = 0;
}

ItemType List::GetNextItem ()
// Pre: No transformer has been executed since last call
// Post:Return value is currentPos@entry
//   Current position has been updated
//   If last item returned, next call returns first item
{
    ItemType item;
    item = data[currentPos];
    if (currentPos == length - 1)
        currentPos = 0;
    else
        currentPos++;
    return item;    
}

void  List::SelSort () 
// Sorts list into ascending order 
{   
    ItemType temp;
    int sIndx;
    int minIndx; // Index of minimum so far    
    
    for (int passCount = 0; passCount < length - 1; passCount++) {

       minIndx = passCount;

       // Find index of smallest value left
       for (sIndx = passCount + 1; sIndx < length; sIndx++)  {
          if (data[sIndx] < data[minIndx])
                minIndx = sIndx;
       }

       temp = data[minIndx];     // Swap 
       data[minIndx] = data[passCount];
       data[passCount] = temp;
   }
}