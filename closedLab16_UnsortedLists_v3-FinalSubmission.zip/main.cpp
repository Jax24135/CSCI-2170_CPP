/*  asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Monday, 11/06/2017
    PROGRAM ID:  main.cpp / Unsorted List Class with Array Implementation
    AUTHOR:  Jonathan Jackson
    INSTALLATION:  MTSU
    REMARKS: This program accepts User Input (from keyboard) and adds these integer
    values to an Unsorted List class until an 'end-of-file' (^d) character is input.
    The values are repeated back to the User's screen and User is prompted
    for a number to remove from the list.
    The final display shows an ascending Sorted List with the number of times a value
    was deleted from the List.
 */

// fill in the blank area
#include "list.h"
#include <iostream>
using namespace std;

// Declare the function "BuildList" here
void BuildList(List &aList);
// Declare the function "DisplayList" here
void Display(List &aList);

int main() {
    
// use the default constructor to declare a List class object named "list1"
    List list1;
    ItemType targetDeletion;

// call the function "BuildList" to build the list "list1". The function prompts the user to enter a number of values and insert them into the list
    BuildList(list1);

// call the function "Display" to display the values in "list1"
    Display(list1);

// use the copy constructor to declare a second List class object named "list2". "list2" is created as a copy of the object "list1"
    List list2(list1);

// Prompt the user to enter an item/value to be deleted from the list "list2"
    cout << "Enter value to delete : ";
    cin >> targetDeletion;
    cout << endl;

// use "DeleteAll" method to delete all the occurrence of that value in "list2"
    list2.DeleteAll(targetDeletion);
    list2.SelSort();

// call the function "Display" to display the values in "list2"
    Display(list2);
    
    return 0;
}

/* define the function "BuildList" below
   Write a "while" loop to read a number of values one by one from the user.
   After a value is read, add the value to the front of the list by applying the "AddAtFront" method.
   The loop terminates when the end of file '^d' ('^d' is the end of file character. It is achieved by pressing the CTRL key and 'd' key together) is detected.
   Requirement: you are required to use the method "AddAtFront" in defining this function
   For testing purposes, enter these numbers: 20 30 20 10 5 20 ^d
*/
void BuildList(List &aList) {
    ItemType value;
    cout << "Enter a value (^d to stop):\n";
    while (cin >> value && !aList.IsFull()) {
        aList.AddAtFront(value);
    }
    cin.clear();
}


/* define the function "DisplayList" below
   The function displays the values in the list one value per line
   Requirements: you are required to use the methods "GetNextItem" and "Reset"
   in defining this function
*/
void Display(List &aList) {
    aList.Reset();
    
    if (aList.IsEmpty()) {
        cout << "This list has no data in it.\n";
    } else {
        cout << aList.Length() << " values in the list:\n";
        for (int i=0; i<aList.Length(); i++) {
            cout << aList.GetNextItem() << endl;
        }
    }
 
    cout << endl;
}