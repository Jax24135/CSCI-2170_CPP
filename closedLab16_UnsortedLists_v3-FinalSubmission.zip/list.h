// Specification file array-based list (“list.h”)
const  int  MAX_LENGTH  =  50;
typedef int ItemType;

#ifndef List_H
#define List_H

class List           // Declares a class data type
{                       

public:               // Public member functions

    List();
    // Default constructor
    // Pre: An Object  is declared
    // Post: An Object is created with $length, $data[], and $currentPos
    
    
    List(const List &rhs);
    // Copy constructor
    // Post: An Object is duplicated into a new Object
    
    bool IsEmpty () const;
    // Post: Return value is true if length is equal
    //  to zero and false otherwise

    bool IsFull ()  const;              
    // Post: Return value is true if length is equal
    //  to MAX_LENGTH and false otherwise

    int  Length ()  const; // Returns length of list 
    // Post: Return value is length

    void Insert (ItemType item);   
    // Pre: length < MAX_LENGTH && item is assigned
    // Post: data[length@entry] == item &&
    //       length == length@entry + 1
    
    void AddAtFront(const ItemType &item);
    // Pre: length < MAX_LENGTH
    // Post: A new ItemType is added to the ARRAY
    //      Previous items are moved down 1-cell
    //      and new item is saved at cell '0'.
    //      $length is increased by 1

    void Delete (ItemType  item);   
    // Pre: length > 0  &&  item is assigned
    // Post: IF item is in data array at entry
    //      First occurrence of item is no longer
    //   in array
    //         && length == length@entry - 1
    //      ELSE
    //       length and data array are unchanged

    void DeleteAll(ItemType &item);
    // Pre: $item is in the ARRAY
    // Post: all instances of $item are removed from ARRAY
    //      or $length is shortened, so persistent values are 'hidden'
    
    bool IsPresent(ItemType  item)  const;
    // Post: currentPos has been initialized.

    void SelSort ();
    // Sorts list into ascending order

    void Reset ();
    // Post: currentPos has been initialized.

    ItemType GetNextItem ();  
    // Pre: No transformer has been executed since last call
    // Post:Return value is currentPos@entry
    //   Current position has been updated
    //   If last item returned, next call returns first item

private:          // Private data members
    int length; // Number of values currently stored
    ItemType data[MAX_LENGTH]; 
    int  currentPos;  // Used in iteration       
};  

#endif