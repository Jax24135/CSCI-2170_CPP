// asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Friday, 09/22/2017
// PROGRAM ID:  count.cpp / Word Ccunter Program
// AUTHOR:  Jonathan Jackson
// INSTALLATION:  MTSU
// REMARKS:  This program accepts a sentence (with whitespace) from a User.
// It analyzes the characters and displays how many words are in the sentence.

#include <iostream>
using namespace std;

int main()
{
	string line; // debugging = "The baby smiles as soon as she wakes up.";
	int counter = 0; // count number of whitespaces
	int loc; // current location of cursor
	
	// Prompt User for a sentence with whitespace
	cout << "Please enter a line of text:\n";
	
	// get a full sentence with whitespace included
	getline(cin,line);
	
	
	// move cursor location to first whitespace && add 1 to counter
	loc = line.find(' ');
	counter++;
	
	// every time a whitespace is hit, add 1 to counter
	// then move cursor to next whitespace to *just* past it
	while (loc != string::npos) {
		counter++;
		loc = line.find(' ',loc+1);
	}
	
	// Display the number of words counted in the sentence
	cout << endl << "There are " << counter << " words in this sentence." << endl << endl;
	
	// Exit program cleanly
	return 0;
}
