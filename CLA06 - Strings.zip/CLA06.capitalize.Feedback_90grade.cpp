// asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Friday 09/22/2017
// PROGRAM ID:  capitalize.cpp / The Capitalization Sentence Problem
// AUTHOR:  Jonathan Jackson
// INSTALLATION:  MTSU
// REMARKS:  This program takes a User input sentence,
// capitalized every word of it, and displays new sentence to User.

#include <iostream>
#include <cctype>
using namespace std;

int main()
{
	string line // User input text
	int loc; // current location of cursor
	
	// Prompt User for a sentence
	getline(cin,line);
	
	// set first location to 1st character in sentence
	loc = 0;
	
	// change first array place to upper
	// confirm this section works correctly
	line[loc] = toupper(line[loc]);


	// continue function for rest of string
	while (loc != string::npos) {
		
		// current location is a whitespace,
		// so 1 character later should be capitalized
		line[loc+1] = toupper(line[loc+1]);
		
		// set current location to next whitespace
		// make sure its AFTER CURRENT POSITION!!
		loc = line.find(' ',loc+1);
	}
	
	// display new capitalized sentence
	cout << endl << line << endl;
	
	// exit program cleanly
	return 0;
}
