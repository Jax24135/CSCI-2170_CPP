#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std;

struct ListItemType {
    int rank;
    string artistName;
    string songTitle;
    int releaseYear;
    
    bool operator != (const ListItemType &rhs) {return rank==rhs.rank && artistName == rhs.artistName &&             songTitle == rhs.songTitle && releaseYear == rhs.releaseYear;}
    bool operator == (const ListItemType &rhs) {return rank==rhs.rank && artistName == rhs.artistName &&             songTitle == rhs.songTitle && releaseYear == rhs.releaseYear;}
};

typedef ListItemType ItemType;
const int MAX_LENGTH = 500;

class List {
public:
    List();
    List(const List &rhs);
    
    // ACCESSSORS
    int Length() const;
    bool IsEmpty() const;
    bool IsFull() ;
    ItemType IsPresent(const ItemType &rhs);
    void Display() const;
    
    // MUTATORS
    void Insert(const ItemType &item);
    void Delete(const string &targetSong);
    
    // ITERATORS
    void Reset();
    ItemType GetNextItem();
    
    ~List();

private:
    int length;
    ItemType data[MAX_LENGTH];
    int currentPos;
};

#endif /* LIST_H */

