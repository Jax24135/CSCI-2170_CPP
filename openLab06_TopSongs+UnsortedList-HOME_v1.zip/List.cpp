#include "List.h"


// default constructor
List::List()
{ length=0;
}

// copy constructor
List::List(const List &rhs) {
    length= rhs.length;
    for (int i=0;i<length;i++) {
        data[i] = rhs.data[i];
    }
    currentPos = rhs.currentPos;
}

// ACCESSORS
int List::Length() const {
    return length;
}

bool List::IsEmpty() const {
    return (length == 0);
}

bool List::IsFull() {
    return (length == MAX_LENGTH);
}

ItemType List::IsPresent (const ItemType &rhs) {
    while (currentPos<length) {
        if (data[currentPos].artistName == rhs.artistName) {
            return data[currentPos];
        }
    }
}

//void List::Display(int choice) { }


// MUTATORS
void List::Insert(const ItemType &item) {
    if (length < MAX_LENGTH) {
        data[length] = item;
        length++;
    } else {
        cerr << "Cannot accept more entries.\n\n";
    }
}

void List::Delete(const string &targetSong) {
    int i=0;
    
    if (!(*this).IsEmpty()) {
        while (i<length && data[i].songTitle != targetSong) {
            i++;
        }
        
        if (i<= length) {
            while (i<=length) {
                data[i] = data[i+1];
                i++;
            }
            length--;
        }
    } else {
        cerr << "This song isn't in the record.\n\n";
    }
}


// ITERATORS2
void List::Reset() {
    currentPos = 0;
}

ItemType List::GetNextItem(){
    if (currentPos == length) {
        currentPos = 0;
        return data[currentPos];
    } else {
        return data[currentPos+1];
    }
}


List::~List()
{ }