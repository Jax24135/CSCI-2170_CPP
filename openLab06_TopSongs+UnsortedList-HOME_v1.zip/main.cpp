#include <iostream>
#include <fstream>
#include <cassert>
#include <string>
#include <iomanip>
#include "List.h"
using namespace std;

void DisplayMenu();
void GetUserChoice(int &choice);
void BuildSongList(List &aList);
void AddSong(List aList);
// void DisplaySong();
void DeleteSong(List &aList);
//DisplayYear();


int main()
{
    List list1;
    int choice;
    string targetName;
    
    BuildSongList(list1);
    
    do {
        DisplayMenu();
        GetUserChoice(choice);
        
        if (choice == 1) {
            DisplayArtistHits(list1);
            
        } else if (choice == 2) {
                AddSong(list1);
        } else if (choice == 3) {
                DeleteSong(list1);
        } else if (choice == 4) {
                //DisplayYear();
        }
        cout << endl;
    } while (choice != 5);

    
    return 0;
}

void BuildSongList(List &aList) {
    ItemType entry;
    fstream myIn;
    
    myIn.open("topsongs.dat");
    assert(myIn);
    
    while(!aList.IsFull() && myIn >> entry.rank) {
        myIn.ignore(100,'\n');
        getline(myIn,entry.artistName);
        getline(myIn,entry.songTitle);
        myIn >> entry.releaseYear;
        myIn.ignore(100,'\n');
        aList.Insert(entry);
    }
    
    myIn.close();
}

// This function displays a menu of choices for User Input
// User chooses between 1-5 (validated in MAIN) 
void DisplayMenu() {
    cout << right << setw(52) << "Billboard Top Song (2012-2015) Management"
         << endl << endl
         << setw(49) << "Please select from the following menu choices:"
         << endl << endl
         << left << setw(11) << ' ' << "1.  Look up top hits by artist\n"
         << setw(11) << ' ' << "2.  Add a new song\n"
         << setw(11) << ' ' << "3.  Delete an existing song\n"
         << setw(11) << ' ' << "4.  Look up top hits by year\n"
         << setw(11) << ' ' << "5.  Exit"
         << endl << endl;
}

void GetUserChoice(int &choice) {
    
    cout << setw(11) << ' ' << "Enter your choice: ";
    cin >> choice;
    cin.ignore(100,'\n');
    cout << setw(0); // restore "0" offset
}

void DisplayArtistHist(const List &aList) {
    string targetName;
    
    cout << "\nEnter the name of the Artist: ";
    getline(cin,targetName);
    cout << endl;
    
    aList.Display(1,targetName,NULL)
    
}

void AddSong(List aList) {
    ItemType newEntry;
    // get info from User
    cout << "\nEnter the new Song Title: ";
    getline(cin,newEntry.songTitle);
    cout << "Enter the Artist Name: ";
    getline(cin,newEntry.artistName);
    cout << "Enter the Song Rank: ";
    cin >> newEntry.rank;
    cin.ignore(100,'\n');
    cout << "Enter the Release Year: ";
    cin >> newEntry.releaseYear;
    cin.ignore(100,'\n');
    
    // add song to list
    aList.Insert(newEntry);
}

void DeleteSong(List &aList) {
    string targetSong;
    
    cout << "\nEnter the Song Title to be deleted: ";
    getline(cin,targetSong);
    aList.Delete(targetSong);
}

