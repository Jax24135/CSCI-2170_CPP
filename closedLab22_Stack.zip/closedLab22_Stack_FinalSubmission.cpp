/* asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Monday, 12/11/2017
 * PROGRAM ID:  main.cpp / Learning STACKs
 * AUTHOR:  Jonathan Jackson
 * INSTALLATION:  MTSU
 * REMARKS: This program automatically reads in a pre-defined data file
 * into a STACK structure and prints the names (reversed from read-in).
 * 
 * Following that, the list of names is printed *again* in the original
 * order they were read-in from the data file.
 * 
 */

#include <iostream>
#include <fstream>
#include <cassert>
#include <stack>
#include <string>

using namespace std;

typedef string ItemType;    // alias for STRING, easier to change later on

int main() {
    
    fstream myIn;             // references the file stream
    string name;              // contains the item to push into STACK
    stack<ItemType> revStack; // contains the names in reversed read-in order
    stack<ItemType> oriStack; // contains the $names in original read-in order
    ItemType name;    
    
    myIn.open("names.dat");   // open DATA file
    assert(myIn);             // confirm DATA file opens successfully
    
    // read in each line of file, store to $name
    while(getline(myIn,name)) {
        revStack.push(name);    // add $name to STACK
    }
    
    // close DATA file
    myIn.close();
    
    cout << "The list of 13 names in reverse order:\n";
    
    // while $oriSTACK contains data
    while (!revStack.empty()) {
        cout << revStack.top() << endl;     //print top item in STACK
        name = revStack.top();              //save top item in $name
        oriStack.push(name);                // add $name to new (reversed stack) original order
        revStack.pop();                     // remove top item from STACK
    }
    
    // 2-degrees of readability separation
    cout << endl << endl;
    
    cout << "The list of 13 names in the original order:\n";
    
    // print list of namea in original orders
    while (!oriStack.empty()) {             // while the STACK isn't empty
        cout << oriStack.top() << endl;     // print the top item
        oriStack.pop();                     // remove top item from STACK
    }
    
    return 0;   // exit program cleanly
}