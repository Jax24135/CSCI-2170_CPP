// fill in the blank area
#include "list.h"
#include <iostream>
using namespace std;

// Declare the function "BuildList" here
void BuildList(List &list1, int &noi);
// Declare the function "DisplayList" here
void Display(List &aList, const int &noi);
int main() {
    
// use the default constructor to declare a List class object named "list1"
    List list1;
    int noi = 0;
    ItemType targetDeletion;

// call the function "BuildList" to build the list "list1". The function prompts the user to enter a number of values and insert them into the list
    BuildList(list1, noi);

// call the function "Display" to display the values in "list1"
    Display(list1, noi);

// use the copy constructor to declare a second List class object named "list2". "list2" is created as a copy of the object "list1"
    List list2(list1);

// Prompt the user to enter an item/value to be deleted from the list "list2"
    cout << "Enter value to delete : ";
    cin >> targetDeletion;
    cout << endl;

// use "DeleteAll" method to delete all the occurrence of that value in "list2"
    list2.DeleteAll(targetDeletion);

// call the function "Display" to display the values in "list2"
    Display(list2, noi);
    
    return 0;
}

/* define the function "BuildList" below
   Write a "while" loop to read a number of values one by one from the user.
   After a value is read, add the value to the front of the list by applying the "AddAtFront" method.
   The loop terminates when the end of file '^d' ('^d' is the end of file character. It is achieved by pressing the CTRL key and 'd' key together) is detected.
   Requirement: you are required to use the method "AddAtFront" in defining this function
   For testing purposes, enter these numbers: 20 30 20 10 5 20 ^d
*/
void BuildList(List &aList, ItemType &noi) {
    ItemType value;
    cout << "Enter a value (^d to stop):\n";
    while (cin >> value && !aList.IsFull()) {
        aList.AddAtFront(value);
    }
    cin.clear();
}


/* define the function "DisplayList" below
   The function displays the values in the list one value per line
   Requirements: you are required to use the methods "GetNextItem" and "Reset"
   in defining this function
*/
void Display(List &aList, const ItemType &noi) {
    aList.Reset();
    
    if (aList.IsEmpty()) {
        cout << "This list has no data in it.\n";
    } else {
        cout << aList.Length() << " values in the list:\n";
        for (int i=0; i<aList.Length(); i++) {
            cout << aList.GetNextItem() << endl;
        }
    }
 
    cout << endl;
}