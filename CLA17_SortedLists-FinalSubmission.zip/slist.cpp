#include "slist.h"

// Default Constructor
slist::slist() {
    length = 0;
}

// Copy Constructor
slist::slist(const slist &rhs) {
    length = rhs.length;
    for (int i = 0; i<length;i++) {
        data[i] = rhs.data[i];
    }
    currentPos = rhs.currentPos;
}

// ACCESSORS
int slist::Length() const {
    return length;
}

bool slist::IsEmpty() const {
    return (length == 0);
}

bool slist::IsFull() const {
    return (length == MAX_LENGTH);
}

bool slist::IsPresent(ItemType &item) const {
    int index=0;
    while ((index<length) && (item != data[index])) {
        index++;
    }
    
    return (index<length);
}

void slist::Display() const {
    cout << "Title: " << data[currentPos].title << endl
         << "Author: " << data[currentPos].author << endl
         << "Publication Year: " << data[currentPos].publicationYear << endl << endl;   
}

void slist::ListBooksByThisAuthor(const string &thisAuthor) {
    bool found = false;
    
    (*this).Reset();
    
    for (int i=0;i<length;i++) {
        if (thisAuthor == data[i].author) {
            Display();
            found = true;
        }
        (*this).GetNextItem();
    }
    
    if (!found)
        cerr << "This author wasn't found in the collection.\n\n";
}

// MUTATORS
void slist::Insert(const ItemType &item) {   
    if (!(*this).IsFull()){
        data[length] = item;
        length++;
    }
}

//branch of Insert() to Sort ItemTypes into List based on $author
void slist::InsertionSort(const ItemType &item) {   
    //int loc = 0;

    // if nothing is in the list, add the first item
    if ((*this).IsEmpty()) {
        data[length] = item;

    // if the list isn't full...allon-sy!
    } else if (!(*this).IsFull()) {

        // move through list until AUTHOR is at proper location
        while(item.author > data[currentPos].author && currentPos<length) {
            currentPos++;
        }
        
        //shift previous cells up based on currentPos
        for (int i=length;i>=currentPos;i--) {
            data[i+1] = data[i];
        }
        data[currentPos] = item; // add item at duplicated cell
    }
    length++;   // we wouldn't be here if we weren't adding anything
}

void slist::Delete(ItemType &item) {
        int index=0;
        while(index<length && item != data[index]) {
            index++;
        }
        if (index<length) {
            data[index] = data[length-1];
            length--;
        }
}

void slist::SortSel() {
    ItemType temp;
    int passCount;
    int sIndx;
    int minIndx;
    
    for (passCount=0;passCount < length-1;passCount++) {
        minIndx = passCount;
        
        for (sIndx = passCount+1;sIndx<length-1;sIndx++) {
            if (data[sIndx] <= data[minIndx])
                minIndx = sIndx;
            
        }
        
        if (minIndx != passCount) {
            temp = data[minIndx];
            data[minIndx] = data[passCount];
            data[passCount] = temp;
        }
    }
        
}

// Iterators
void slist::Reset() {
    currentPos = 0;
}

ItemType slist::GetNextItem() {
    ItemType item;
    item = data[currentPos];
    if(currentPos == length-1)
        currentPos = 0;
    else
        currentPos++;
    return item;
}

slist::~slist() {
} // Destructor