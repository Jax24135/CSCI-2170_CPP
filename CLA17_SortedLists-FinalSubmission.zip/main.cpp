/*  asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Monday, 11/13/2017
    PROGRAM ID:  main.cpp / Sorted List with Struct Type Data
    AUTHOR:  Jonathan Jackson
    INSTALLATION:  MTSU
    REMARKS: This program reads in a pre-determined data file BookType struct
    as a (Author-sort) Sorted List.
    Afterwards, *this prints the author/title/year info to the User screen.
    The User is prompted for an $author to search for and any book by $author
    is printed to the screen.
 */

#include "slist.h"
#include <iostream>
#include <fstream>
#include <cassert>
using namespace std;

int main()
{
    fstream myIn;   // contains the data file
    int size = 0;   // contains the public $length
    BookType aBook; // tmp struct placeholder for saving items to Sorted List
    slist list1;    // Sorted List 1
    string targetName;  // author name to search for
    
    myIn.open("books.dat");     // open file
    assert(myIn);               // confirm file opened okay
    
    
    // Read in data into $title/$author/$publicationYear
    while (size<MAX_LENGTH && getline(myIn,aBook.title)) {
        getline(myIn,aBook.author);
        
        myIn >> aBook.publicationYear; // keeps int as int
        myIn.ignore(100,'\n');
        
        list1.Reset(); //uh...this does $magic
        list1.InsertionSort(aBook); // add item to Sorted List
        size++; // prevents SEG_FAULT
    }
    
    myIn.close();   // yep.. this.. does this
    
    cout << "The list of books are:\n\n";
    
    list1.Reset();  // because I was told to
    
    //print list of titles
    for (int i=0;i<list1.Length();i++) {
        list1.Display();
        list1.GetNextItem();
    }
    // get $targetName to search for
    cout << "Please enter the name of the author : ";
    getline(cin,targetName);
    cout << endl;
    
    // display books by $targetName
    cout << "The list of books are:\n\n";
    list1.ListBooksByThisAuthor(targetName);
    
    return 0;   // exit program cleanly...fingers crossed here *X*
}