#ifndef SLIST_H
#define SLIST_H

#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
using namespace std;

struct BookType {
    string title;           // contains Book title
    string author;          // contains Book author
    int publicationYear;    // contains Book publication year
    
    bool operator <= (const BookType &rhs) { return (author <= rhs.author); }
    bool operator != (const BookType &rhs) {return (author == rhs.author); }
};

const int MAX_LENGTH = 50;  // max array size
typedef BookType ItemType;  // alias for BookType

class slist {
public:
    
    // default constructor
    slist();
    
    // copy constructor
    slist(const slist &rhs);
    
    // ACCESSORS
    bool IsEmpty() const;
    // Pre: a list exists
    // Post: return TRUE if nothing is in the list
    
    bool IsFull() const;
    // Post: return TRUE if the list has reached max length
    
    bool IsPresent(ItemType &item) const;
    // Post: returns TRUE if $item is in the slist
    
    int  Length() const;
    // Post: returns the length of the list
    
    void Display() const;
    // Post: displays the headings and title/author/publicationYear to User screen
    
    //MUTATORS
    void Insert(const ItemType &item);
    //Pre: List has room for another $item
    //Post: list now has $item in it.
    
    void InsertionSort(const ItemType &item);
    // Pre: List has room for another $item
    // Post: $Item is sorted into list at proper location
    //       $length is increased by 1
    
    void Delete(ItemType &item);
    // Pre: $item is already in list
    // Post: item is removed from list and length is decreased by 1
    
    void SortSel();
    // Pre: List is Unsorted
    // Post: List is Sorted (reference BookType Struct for <= operator)
    
    void ListBooksByThisAuthor(const string &thisAuthor);
    // Post: If $thisAuthor is found, Display() shows the title/author/and publicationYear
    // associated with each book associated with $thisAuthor
    // If author, is not found - an error message is displayed
    
    // ITERATORS
    void Reset();
    // Post: currentPos is set to '0'
    
    ItemType GetNextItem();
    // Post: returns the next $item in *this list
    //       if at end of list, it loops back to '0'-position
    
    
    //destructor
    ~slist();
    
private:
    int length; // list length
    ItemType data[MAX_LENGTH]; // array data of ItemType (BookType)
    int currentPos; // current position in relation to list
};

#endif