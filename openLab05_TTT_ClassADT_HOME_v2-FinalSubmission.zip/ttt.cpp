#include "ttt.h"

// default constructor
TTT::TTT() {
    for (int i=0; i<SIZE; i++) { // ROWs
        for (int j=0; j<SIZE; j++) { // COLs
            gameBoard[i][j] = ' ';
	}
    }
}

// copy constructor
TTT::TTT(const TTT &rhs) {
    for (int i=0; i<SIZE; i++) {
        for (int j=0;j<SIZE;j++) {
            gameBoard[i][j] = rhs.gameBoard[i][j];
        }
    }    
}

// MUTATOR
// assigns Player's Mark to empty cells
bool TTT::Assign(const int &x, const int &y, const char &playerTurn) {
    if (gameBoard[x][y] == ' ') {
        gameBoard[x][y] = playerTurn;
        return true;
    } else {
        return false;
    }
}

// ACCESSORS
// show the current game board
void TTT::Display() const {
    cout << "Current Game Board:\n";
	
    //for each ROW...
    for (int i=0; i<SIZE; i++){	// ROWs
        // and each COLUMN...
	for (int j=0; j<SIZE;j++) { //COLs
            
            // print what CHAR is located there, ' ','X', or 'O'
            cout << gameBoard[i][j];
			
            //keep the pipes to 2 per line
            if (j<2) {
                cout << " | ";
            }
        }
	
    // print a horizontal dividing line after each ROW
    cout << "\n-----------\n";
    }
}

// Check gameBoard for a winner
char TTT::CheckWon() const {
    char won = 'n';
    
    // write multiway if statement to check whether a win condition is met
    for (int i=0 ; i<SIZE; i++) {
            
    	// check rows for same non-' ' CHARS
        if ((gameBoard[i][0] != ' ') && (gameBoard[i][0] == gameBoard[i][1]) && (gameBoard[i][1] == gameBoard[i][2]))
            return won = gameBoard [i][0];
        
	//check columns for same non-' ' CHARS
        else if ((gameBoard[0][i] != ' ') && (gameBoard[0][i] == gameBoard[1][i]) && (gameBoard[1][i] == gameBoard[2][i]))
            return won = gameBoard[0][i];
            
	// check for a left-to-right diagonal win
        else if ((gameBoard[0][0] != ' ') && (gameBoard[0][0] == gameBoard[1][1]) && (gameBoard[1][1] == gameBoard[2][2]))
            return won = gameBoard[1][1];
            
	// check for a right-to-left diagonal win
        else if ((gameBoard[2][0] != ' ') && (gameBoard[2][0] == gameBoard[1][1]) && (gameBoard[1][1] == gameBoard[0][2])) 
            return won = gameBoard[1][1];
    }
    return won;
}

// Check gameBoard for empty spaces, if none exist return TRUE
bool TTT::BoardIsFull() const {
    //set up loop $vars and $counter
    int counter = 9;
    
    // go through the gameBoard, if Array cell isn't empty, remove 1 from counter
    for (int i=0;i<SIZE;i++) { // ROWS
        for (int j=0 ; j<SIZE ; j++) { // COLs
            if (gameBoard[i][j] != ' ') {
                counter--;
            }
        }
    }

    // if counters are all gone, return TRUE (board IS full)
    if (counter == 0) {
        return true;
    } else {
        return false;
    }
}

// destructor
TTT::~TTT() {
}