// asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Tuesday, 11/07/2017
// PROGRAM ID: main.cpp / Tic-Tac-Toe Game as a Class (OLA 5)
// AUTHOR:  Jonathan Jackson
// INSTALLATION:  MTSU
// REMARKS:  Tic-Tac-Toe game consisting of 3x3 game board of squares
// where each square is either empty, has an 'X' marker, or has an 'O' marker.
// Two players represented by an X or an O play the game.
// The objective is for one player to get three Xs or three Os in a row first.
//
// Use your class to create a game that prompts for player X and player O
// to place ‘X’ or ‘O’ markers at specified locations on the game board.
// After each move, your program should display the current game board to the user.
// Your program should also check after each move if there is a winner
// If so, the game should complete by indicating which player won.

#include <iostream>
#include <string>
#include "ttt.h"
using namespace std;

void DetermineFirstTurn(char &playerTurn);

int main()
{
    TTT game;           // builds the game board
    char playerTurn;    // store the current player's mark/turn
    int x, y;           // stores x-y gameBoard coordinates
    
    cout << "Game Starts!\n";
    game.Display();  // initial display of gameBoard
    
    // set 1st player's turn
    DetermineFirstTurn(playerTurn);
    
    // while the board isn't full and no one's won the game, play on!
    while(!game.BoardIsFull() && game.CheckWon() == 'n') {

        // if requested cell is already claimed, prompt PLayer again
        do {
            // while x/y values aren't valid, keep prompting for values
            do {
                cout << "Player " << playerTurn << " makes the next move.\n"
                     << "Enter the x,y location, 0<=x<3, 0<=y<3: ";
                cin >> x >> y;
            } while(x>2 || x<0 || y>2 || y<0);
        } while(!game.Assign(x,y,playerTurn));
        
        // after successful Assignment, show updated gameBoard
        game.Display();
        
        // switch to other Player
        if (playerTurn == 'X')
            playerTurn = 'O';
        else
            playerTurn = 'X';
    }
    
    // once there's a winner, or the board is full - print final game results
    if (game.CheckWon() == 'X')
        cout << "Player X wins!\n";
    else if (game.CheckWon() == 'O')
        cout << "Player O wins!\n";
    else
      cout << "This is a Draw game!\n";
    
    return 0; // Exit program cleanly
}


// User-Defined Functions
void DetermineFirstTurn(char &playerTurn) {
    int tmp = rand() % 2;
    if (tmp == 1)
        playerTurn = 'X';
    else
        playerTurn = 'O';
}