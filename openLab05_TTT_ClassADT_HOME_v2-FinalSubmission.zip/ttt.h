#ifndef  TTT_H
#define  TTT_H

#include <iostream>
#include <string>
using namespace std;

const int SIZE=3;
/* Minimally, you need these operations for the TTT class
You are free to add additional methods if needed */

class TTT
{

public:

    TTT();
    // Post: Each of the 9 spaces of the gameBoard is initialized
    // to a ' ' (blank space).
    
    TTT(const TTT &rhs);
    // copy constructor - for testing hypothetical outcomes based on
    // current game.
    // Pre: a previous TTT game exists
    // Post: an unlinked copy of the TTT game will exist (i.e. 'game2')

    // MUTATORS
    bool Assign(const int &x, const int &y, const char &playerTurn);
    // Pre: while x is between 0 and 2, and y is between 0 and 2
    // Post: If the requested space is empty (' '), the current player's mark ('X' or 'O')
    //will be set there and return true
    // if space is already claimed - it returns false
    
    // ACCESSORS
    void Display() const;
    // Pre: An TTT Object has already been built.
    // Post: a 'current game board' header
    // and the Array values ('X','O', or ' ') formatted with '-' and '|' is displayed
    
    bool BoardIsFull() const;
    // Check to see if there is any blank square left on the gameboard (to continue to play).
    // Returns true of false depending on whether the gameboard is full or not
    
    char CheckWon() const;
    // Check whether one player won:
    // if player 'X' wins, return 'X',
    // if player 'O' wins, return 'O',
    // if no player wins yet, return 'N'.

    ~TTT(); //destructor
    
    private:
    char gameBoard[SIZE][SIZE]; // The game board Array
    
};
#endif