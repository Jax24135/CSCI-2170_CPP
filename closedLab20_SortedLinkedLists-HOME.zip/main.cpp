// fill in the blank area

#include <fstream>
#include <iostream>
#include <string>
#include <cassert>
using namespace std;

typedef string ListItemType;

struct Node {
    ListItemType data;
    Node * next;
};

typedef Node * NodePtr;

// Declare the function "BuildSortedList" here
void BuildSortedList(NodePtr &head);

// Declare the function "SortedListInsert" here

// Declare the function "DisplayList" here
void DisplayList(NodePtr &head);
// Declare the function "DestroyList" here

int main() {
    
    NodePtr head = NULL;

    // call function "BuildSortedList" to read data from the data file and
    // construct the list
    BuildSortedList(head);

    // call function "DisplayList" to display the list
    DisplayList(head);
    
    // call function "DestroyList" here

return 0; }

// define the function "BuildSortedList" below
// Write a "while" loop to read position-item pairs from the data file.
// insert the item into the list at the specified position. Call "SortedListInsert" function for insertion.
// The loop terminates when the end of the data file is reached.

void BuildSortedList(NodePtr &head) {
    ifstream myIn;
    ListItemType item;
    NodePtr newNode, prevNode, currNode;
    newNode = new Node;
    
    myIn.open("produce.dat");
    assert(myIn);
    int counter = 0;
    
    while (myIn >> item && counter < 4) {
        newNode->data = item;
        newNode->next = NULL;
        
        if(head == NULL) {
            head = newNode;
            prevNode = currNode = head;
        } else {
            //if data is less than
            while(currNode != NULL && counter < 4) {
                if (newNode->data < currNode->data) {
                    prevNode = currNode;
                    currNode = currNode->next;
                } else if (newNode->data > currNode->data) {
                    prevNode->next = newNode;
                    newNode->next = currNode;
                } else {
                    newNode->next = head;
                    head = newNode;
                }
                counter++;
                
            }
        }
    }
    
    myIn.close();
}
// define the function "SortedListInsert" below

// define the function "DisplayList" below
void DisplayList(NodePtr &head) {
    NodePtr locPtr = head;
    int counter=0;
   
    while (locPtr != NULL && counter<4) {
        if (head == NULL) {
            cout << "this list is empty.\n\n";
        } else {
            cout << locPtr->data << endl;
            locPtr = locPtr->next;
        }
        counter++;
    }
}


// define the function "DestroyList" below 